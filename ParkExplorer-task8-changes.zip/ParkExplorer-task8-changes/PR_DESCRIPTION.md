# Task 8: Responsible-recreation rules (+ Task 7 review fixes)

## Task 7 review fixes
- Refilling the canteen no longer gives free Stewardship or instant hydration, and does nothing when full
- Hydration meter no longer redraws the whole game ~60 times a second (updates about once a second)
- Running low on water (<15%) slows stamina recovery and speeds up sprint fatigue
- "Trail Safety Bell" replaced by an honest "Emergency Rescue Whistle"
- First-aid kit description lists both effects; starting canteen shown as free starting gear
- Download button on GitHub Pages fixed (relative link, file copied into dist)
- package.json renamed to park-explorer; unused express, dotenv and Gemini packages removed

## Task 8
- Wildlife distance banner within 23 m (25 yards), with teaching text
- Small Stewardship penalty for startling wildlife (20 s cooldown)
- Closed area (roped off, signed, explained) and fragile area (warning, small penalty after 6 s off-trail) in each park
- 5 pieces of litter per park, picked up with Q (+3 Credits, +1 Stewardship, once per piece)
- Park Rules card on the start screen. All rules are game content, not official NPS rules

## Testing
Type-check and build pass. Placement, scoring and startle logic checked with scripts. Not yet played in a browser.
